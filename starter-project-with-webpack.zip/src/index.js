import '../src/styles/styles.css';
import Router from '../src/scripts/routes/routes.js';

document.addEventListener('DOMContentLoaded', () => {
  Router.init();
});